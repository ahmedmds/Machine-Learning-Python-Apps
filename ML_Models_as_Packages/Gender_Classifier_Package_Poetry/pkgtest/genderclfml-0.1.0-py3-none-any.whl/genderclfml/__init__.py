from .genderclfml import GenderClassifier
__version__ = '0.1.0'
